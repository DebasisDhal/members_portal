import { Component } from '@angular/core';

@Component({
  selector: 'app-recently-view',
  templateUrl: './recently-view.component.html',
  styleUrl: './recently-view.component.css'
})
export class RecentlyViewComponent {

}
